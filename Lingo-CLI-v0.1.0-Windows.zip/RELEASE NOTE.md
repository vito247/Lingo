# Lingo v0.1.0

- Added standard Lingo syntax.