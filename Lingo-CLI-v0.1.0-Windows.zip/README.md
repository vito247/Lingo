# Lingo CLI v0.1.0

Lingo is simple interpreted programming language written in C++.  
Lingo uses a readable, indentation-based syntax designed to be easy to understand.
This is public pre-release of Lingo CLI.

## Features
- Lingo CLI  
- Lingo interpreter  
